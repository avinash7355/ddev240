<script>
console.log('Customer_Addblock::js/default.js');
</script>
