<?php
namespace Brainvire\Uiforms\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;
use Magento\Framework\Filesystem\Directory\ReadFactory;

class FileList implements ArrayInterface
{
    protected $mediaDirectory;

    public function __construct(
        ReadFactory $readFactory,
        \Magento\Framework\Filesystem $filesystem
    ) {
        $this->mediaDirectory = $readFactory->create($filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA));
    }

    public function toOptionArray()
    {
        $options = [];
        $importDir = 'import'; // Adjust this if necessary

        $files = $this->mediaDirectory->read($importDir);
        foreach ($files as $file) {
            if ($file->isFile()) {
                $options[] = [
                    'value' => $file->getName(),
                    'label' => $file->getName(),
                ];
            }
        }

        return $options;
    }
}
