define([
    'Magento_Ui/js/form/element/file-uploader',
    'uiRegistry'
], function (Element, registry) {
    'use strict';

    return Element.extend({
        initialize: function () {
            this._super();

            var importField = registry.get('fields_form.fields.import_xml');
            this.value.subscribe(function (file) {
                importField.value(file);
            });

            importField.value.subscribe(function (value) {
                this.value(value);
            }, this);
        }
    });
});
