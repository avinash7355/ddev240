<?php
namespace Brainvire\Formfront\Block;

use Magento\Framework\View\Element\Template;
use Brainvire\Formfront\Model\ResourceModel\Form\CollectionFactory;

class DisplayData extends Template
{
    protected $formCollectionFactory;

    public function __construct(
        Template\Context $context,
        CollectionFactory $formCollectionFactory,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->formCollectionFactory = $formCollectionFactory;
    }

    public function getFormData()
    {
        // Replace 'name', 'email', 'phone_number' with actual field names
        $collection = $this->formCollectionFactory->create()
            ->addFieldToSelect(['name', 'email', 'phone_number'])
            ->setOrder('entity_id', 'desc') // Optional: Sort data by entity_id in descending order
            ->setPageSize(10); // Optional: Limit the number of records to display

        return $collection->getData();
    }
}
