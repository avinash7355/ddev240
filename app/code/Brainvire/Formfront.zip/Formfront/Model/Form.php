<?php
namespace Brainvire\Formfront\Model;

use Magento\Framework\Model\AbstractModel;
use Brainvire\Formfront\Model\ResourceModel\Form as FormResource;

class Form extends AbstractModel
{
    protected function _construct()
    {
        $this->_init(FormResource::class);
    }
}
