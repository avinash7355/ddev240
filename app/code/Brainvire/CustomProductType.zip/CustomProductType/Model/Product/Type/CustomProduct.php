<?php
namespace Brainvire\CustomProductType\Model\Product\Type;

class CustomProduct extends \Magento\Catalog\Model\Product\Type\AbstractType
{
    const TYPE_CODE= 'new_product_type_code';
    
    public function deleteTypeSpecificData(\Magento\Catalog\Model\Product $product)
    {
    }
}