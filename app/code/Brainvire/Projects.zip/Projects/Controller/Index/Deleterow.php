<?php

namespace Brainvire\Projects\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Brainvire\Projects\Model\ProjectsFactory;
use Magento\Framework\Controller\Result\JsonFactory;

class Deleterow extends Action
{
    protected $projectsFactory;
    protected $resultJsonFactory;

    public function __construct(
        Context $context,
        ProjectsFactory $projectsFactory,
        JsonFactory $resultJsonFactory
    ) {
        parent::__construct($context);
        $this->projectsFactory = $projectsFactory;
        $this->resultJsonFactory = $resultJsonFactory;
    }

    public function execute()
    {
        $projectId = $this->getRequest()->getParam('entity_id');
        $result = [];

        if ($projectId) {
            try {
                $project = $this->projectsFactory->create();
                $project->load($projectId);
                $project->delete();
                $result['success'] = true;
                $result['message'] = __('Project has been deleted.');
            } catch (\Exception $e) {
                $result['success'] = false;
                $result['message'] = __('An error occurred while deleting the project: %1', $e->getMessage());
            }
        } else {
            $result['success'] = false;
            $result['message'] = __('Project ID is missing.');
        }

        // Return JSON response
        $resultJson = $this->resultJsonFactory->create();
        return $resultJson->setData($result);
    }
}
