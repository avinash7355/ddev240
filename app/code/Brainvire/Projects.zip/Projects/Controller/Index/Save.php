<?php

namespace Brainvire\Projects\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Brainvire\Projects\Model\Projects;

class Save extends Action
{
    protected $jsonFactory;
    protected $projectsModel;

    public function __construct(
        Context $context,
        JsonFactory $jsonFactory,
        Projects $projectsModel // Use your actual model class
    ) {
        parent::__construct($context);
        $this->jsonFactory = $jsonFactory;
        $this->projectsModel = $projectsModel;
    }

    public function execute()
    {
        $result = $this->jsonFactory->create();
        $response = ['success' => false, 'error' => ''];


        try {
            $data = $this->getRequest()->getPostValue();
            

            if ($data && isset($data['entity_id'])) {
                $entityId = $data['entity_id'];
                $description = $data['description'];
                $customerId = $data['customer_id'];
                $status = $data['status'];

                // Perform any data processing and validation here

                // Save data to the database using your model
                $project = $this->projectsModel->load($entityId); // Load the existing project if needed
                $project->setDescription($description);
                $project->setCustomerId($customerId);
                $project->setStatus($status);
                $project->save();

                $response['success'] = true;
            } else {
                $response['error'] = 'Invalid data';
            }
        } catch (\Exception $e) {
            $response['error'] = $e->getMessage();
        }

        return $result->setData($response);
    }
}
