<?php
namespace Brainvire\SampleGrid\Model\ResourceModel\Post;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Brainvire\SampleGrid\Model\Post', 'Brainvire\SampleGrid\Model\ResourceModel\Post');
    }

    /**
     * Add join with catalog_product_entity table to fetch attribute_id
     *
     * @return $this
     */
    protected function _initSelect()
    {
        parent::_initSelect();

        $this->getSelect()->joinLeft(
            ['product' => $this->getTable('catalog_product_entity')],
            'main_table.product_id = product.entity_id',
            ['attribute_id' => 'product.attribute_id']
        );

        return $this;
    }
}
