<?php
namespace Vendor\Module\Model;

use Magento\Framework\Model\AbstractModel;
use Vendor\Module\Model\ResourceModel\Image as ImageResource;

class Image extends AbstractModel
{
    protected $_idFieldName = 'id'; // Adjust this to match your database table's primary key field name

    protected function _construct()
    {
        $this->_init(ImageResource::class);
    }

    /**
     * @return int
     */
    public function getImageId()
    {
        return $this->getData('id');
    }

    /**
     * @param int $imageId
     * @return $this
     */
    public function setImageId($imageId)
    {
        return $this->setData('id', $imageId);
    }

    /**
     * @return string|null
     */
    public function getImageName()
    {
        return $this->getData('image_name');
    }

    /**
     * @param string $imageName
     * @return $this
     */
    public function setImageName($imageName)
    {
        return $this->setData('image_name', $imageName);
    }
}
