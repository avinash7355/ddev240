<?php declare(strict_types=1)
namespace Brainvire\SampleGrid\Controller\Adminhtml\Post;
use Magento\Backend\App\Action;
use Magento\Framework\App\Action\httpPostActionInterface;
use Magento\Framework\Controller\ResultInterface