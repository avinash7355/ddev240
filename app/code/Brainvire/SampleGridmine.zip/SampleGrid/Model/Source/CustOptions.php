<?php
/**
 * Code standard by : RH
 */
namespace Brainvire\SampleGrid\Model\Source;

use Magento\Framework\Data\OptionSourceInterface;

class CustOptions implements OptionSourceInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        $options = [
            [
                'value' => 'mobile_accessories',
                'label' => __('Mobile Accessories')
            ],
            [
                'value' => 'toys',
                'label' => __('Toys')
            ],
          
        ];
        
        return $options;
    }
}
