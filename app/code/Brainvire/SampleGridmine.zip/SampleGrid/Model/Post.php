<?php
namespace Brainvire\SampleGrid\Model;
class Post extends \Magento\Framework\Model\AbstractModel
{
	protected function _construct()
	{
		$this->_init('Brainvire\SampleGrid\Model\ResourceModel\Post');
	}
}